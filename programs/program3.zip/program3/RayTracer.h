//
// Created by gross on 4/22/2018.
//
#include "Camera.h"
#include "Color.h"
#include "Ray.h"
#ifndef GLFW_EXAMPLE_RAYTRACER_H
#define GLFW_EXAMPLE_RAYTRACER_H

class RayTracer{
public:
    int width;
    int height;
    int maxReflections;
    int superSamples; // Square root of number of samples to use for each pixel.
    Camera camera;
    double imageScale;
    int depthComplexity;
    double dispersion;
    unsigned long long raysCast;
    RayTracer(int width_, int height_, int maxReflections_) : width(width_), height(height_),
                                                 maxReflections(maxReflections_), camera(Camera()),
                                                 imageScale(1), dispersion(5.0f), raysCast(0){}
Color castRayForPixel(int x, int y) {
    double rayX = (x - width / 2)/2.0;
    double rayY = (y - height / 2)/2.0;
    double pixelWidth = rayX - (x + 1 - width / 2)/2.0;
    double sampleWidth = pixelWidth / superSamples;
    double sampleStartX = rayX - pixelWidth/2.0;
    double sampleStartY = rayY - pixelWidth/2.0;
    double sampleWeight = 1.0 / (superSamples * superSamples);
    Color color;

    for (int x = 0; x < superSamples; x++) {
        for (int y = 0; y < superSamples; y++) {
            Vector imagePlanePoint = camera.lookAt -
                                     (camera.u * (sampleStartX + (x * sampleWidth)) * imageScale) +
                                     (camera.v * (sampleStartY + (y * sampleWidth)) * imageScale);

            color = castRayAtPoint(imagePlanePoint;
        }
    }

    return color;
}

    Color castRayAtPoint(const Vector& point) {
        Color color;

        for (int i = 0; i < depthComplexity; i++) {
            Ray viewRay(camera.position, point - camera.position, maxReflections);

            if (depthComplexity > 1) {
                Vector disturbance(
                        (dispersion / RAND_MAX) * (1.0f * rand()),
                        (dispersion / RAND_MAX) * (1.0f * rand()),
                        0.0f);

                viewRay.origin = viewRay.origin + disturbance;
                viewRay.direction = point - viewRay.origin;
                viewRay.direction = viewRay.direction.normalize();
            }

            color = castRay(viewRay);
        }

        return color;
    }

};
#endif //GLFW_EXAMPLE_RAYTRACER_H
