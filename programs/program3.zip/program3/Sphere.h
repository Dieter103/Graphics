//
// Created by gross on 4/23/2018.
//

#ifndef GLFW_EXAMPLE_SPHERE_H
#define GLFW_EXAMPLE_SPHERE_H
#include "Sphere.h"
#include "Vector.h"
#include "Ray.h"
#include "Color.h"
#include "Intersection.h"
#include "Light.h"
#include <math.h>
class Sphere{
public:
    Vector center;
    double radius;
    Color color;
    Material* material;
    int id;


    Sphere(const Vector& center=Vector(0,0,0),
        float radius=0,
        const Color color=Color(0,0,0)) : center(center), radius(radius), color(color)
        {
            static int id_seed = 0;
            id = ++id_seed;
        }



    Intersection intersect(Ray ray) const
    {
        Vector l =  ray.origin-center;
        float tca = l.dot(ray.direction);
        if (tca < 0) return Intersection();
        float d2 = l.dot(l) - tca * tca;
        if (d2 > radius) return Intersection();
        float thc = sqrt(radius - d2);

        Vector deltap = ray.origin - center;
        double a = ray.direction.dot(ray.direction);
        double b = deltap.dot(ray.direction) * 2;
        double c = deltap.dot(deltap) - (radius * radius);

        double disc = b * b - 4 * a * c;

        double q;
        if (b < 0) {
            q = (-b - disc) * 0.5;
        } else {
            q = (-b + disc) * 0.5;
        }

        double r1 = q / a;
        double r2 = c / q;

        if (r1 > r2) {
            double tmp = r1;
            r1 = r2;
            r2 = tmp;
        }

        double distance = r1;
        if (distance < 0) {
            distance = r2;
        }



        Vector point = ray.origin + (ray.direction * distance);
        Vector normal = (point - center).normalize();


        return Intersection(ray, point, distance, normal);
    }

    Color performLighting(const Intersection& intersection, Color intersectionColor) {
        Color color = intersectionColor;
        Color ambientColor = getAmbientLighting(intersection, color);
        Color diffuseAndSpecularColor = getDiffuseAndSpecularLighting(intersection, color);
//        Color reflectedColor = getReflectiveRefractiveLighting(intersection);

        return ambientColor + diffuseAndSpecularColor;
    }

    Color getAmbientLighting(const Intersection& intersection, const Color& color) {
        return color * 0.2;
    }

    Color getDiffuseAndSpecularLighting(const Intersection& intersection,
                                                   const Color& color) {
        Color diffuseColor(0.0, 0.0, 0.0);
        Color specularColor(0.0, 0.0, 0.0);

//        for (vector<Light*>::iterator itr = lights.begin(); itr < lights.end(); itr++) {
            Light light = Light(Vector(-10,10,-50),0.4);
            Vector lightOffset = light.position - intersection.intersection;
            double lightDistance = lightOffset.length();
            /**
             * TODO: Be careful about normalizing lightOffset too.
             */
            Vector lightDirection = lightOffset.normalize();
            double dotProduct = intersection.normal.dot(lightDirection);

            /**
             * Intersection is facing light.
             */
            if (dotProduct >= 0.0f) {
//                Ray shadowRay = Ray(intersection.intersection, lightDirection, 1,
//                                    intersection.ray.material);

//                if (isInShadow(shadowRay, lightDistance)) {
//                    /**
//                     * Position is in shadow of another object - continue with other lights.
//                     */
//                    continue;
//                }

                diffuseColor = (diffuseColor + (color * dotProduct)) *
                               light.intensity;
                specularColor = specularColor + getSpecularLighting(intersection, &light);
            }


        return diffuseColor + specularColor;
    }

    Color getSpecularLighting(const Intersection& intersection,
                              Light* light) {
        Color specularColor(0.0, 0.0, 0.0);
//        double shininess = intersection.endMaterial->getShininess();

//        if (shininess == NOT_SHINY) {
//            /* Don't perform specular lighting on non shiny objects. */
//            return specularColor;
//        }

        Vector view = (intersection.ray.origin - intersection.intersection).normalize();
        Vector lightOffset = light->position - intersection.intersection;
        Vector reflected = reflectVector(lightOffset.normalize(), intersection.normal);

        double dot = view.dot(reflected);

        if (dot <= 0) {
            return specularColor;
        }

        double specularAmount = pow(dot, 200) * light->intensity;

        specularColor.r = specularAmount;
        specularColor.g = specularAmount;
        specularColor.b = specularAmount;

        return specularColor;
    }

    Vector reflectVector(Vector vector, Vector normal) {
        return normal * 2 * vector.dot(normal) - vector;
    }

};
//
//
//Intersection intersect(Ray ray) {
//    Vector deltap = ray.origin - center;
//    double a = ray.direction.dot(ray.direction);
//    double b = deltap.dot(ray.direction) * 2;
//    double c = deltap.dot(deltap) - (radius * radius);
//
//    double disc = b * b - 4 * a * c;
//    if (disc < 0) {
//        return Intersection(); // No intersection.
//    }
//
//    disc = sqrt(disc);
//
//    double q;
//    if (b < 0) {
//        q = (-b - disc) * 0.5;
//    } else {
//        q = (-b + disc) * 0.5;
//    }
//
//    double r1 = q / a;
//    double r2 = c / q;
//
//    if (r1 > r2) {
//        double tmp = r1;
//        r1 = r2;
//        r2 = tmp;
//    }
//
//    double distance = r1;
//    if (distance < 0) {
//        distance = r2;
//    }
//
//    if (distance < 0 || isnan(distance)) {
//        return Intersection(); // No intersection.
//    }
//
//    Vector point = ray.origin + (ray.direction * distance);
//    Vector normal = (point - center).normalize();
//
////    normal = material->modifyNormal(normal, point);
//
//    // Normal needs to be flipped if this is a refractive ray.
//    if (ray.direction.dot(normal) > 0) {
//        normal = normal * -1;
//    }
//
//    return Intersection(ray, point, distance, normal, this);
//}

//Boundaries Sphere::getBounds() {
//    return bounds;
//}};

#endif //GLFW_EXAMPLE_SPHERE_H
